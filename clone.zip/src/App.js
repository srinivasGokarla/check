import "./App.css";
import ResponsiveAppBar from "./Components/TopNavbar"
import PrimarySearchAppBar from "./Components/Navbar"
import {Restaurant} from "./Components/Restaurant"

function App() {
 

  return (
    <div className="App">
     < ResponsiveAppBar/>
     <PrimarySearchAppBar />
     < Restaurant />
    </div>
  );
}

export default App;

