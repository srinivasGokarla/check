import { useState, useEffect } from "react";
import "../App.css";
import DBJSON from "../data.json";
import axios from "axios";


export const Restaurant = () => {
  // total obj in array.

  const { restaurant } = DBJSON;
  const initialData = restaurant || [];
  const [data, setData] = useState(initialData);
  const [showall, setShowall] = useState(initialData);
  const [item, setItem] = useState([]);
  const [filterState, setFilterState] = useState({
    method: "all",
    rating: 1,
  });
  const [sortByRating, setSortByRating] = useState(false);

  // single obj initial state
  const initialState = {
    username: "",
    address: "",
    payment_methods: {
      card: false,
      cash: false,
      upi: false,
      all: true,
    },
    votes: "",
    reviews: "",
    image: "",
    costforone: "",
    min: "",
    address1: "",
    rating: "all",
  };

  const [formData, setformData] = useState(initialState);

  const handlesubmit = (e) => {
    e.preventDefault();
    const showalladata = () => {
      return [...data, formData];
    };
    setData(showalladata);
    setShowall(showalladata);
  };
  console.log(showall);

  const handlePaymentMethodChange = (e) => {
    const { value } = e.target;

    const payment_methods = {
      card: false,
      cash: false,
      upi: false,
    };

    payment_methods[value] = true;

    setformData((prevState) => ({
      ...prevState,
      payment_methods,
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(name, "name", value, "value");

    setformData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const sortByRatingFunc = () => {
    setSortByRating((prev) => !prev);
  };

  const getCorrectPaymentMethod = (obj) => {
    for (let key in obj) {
      if (obj[key]) return key;
    }
  };
  const handlesorting = (rate) => {
    setFilterState({ ...filterState, rating: rate });
  };

  const handlepayment = (method) => {
    setFilterState({ ...filterState, method });
  };
  function getRestaurant() {
    fetch("http://localhost:3000/restaurant")
      .then((data) => data.json())
      .then((data) => {
        setFilterState(data);
        console.log(data);
      });
  }



  useEffect(() => {
    const filterSearch = () => {
      const { method, rating } = filterState;
  
      let filteredArr = showall.filter((item) => {
        let newitem = item.payment_methods[method] && item.rating >= rating;
        return newitem;
      });
  
      filteredArr = filteredArr.sort((a, b) =>
        sortByRating ? b.rating - a.rating : a.rating - b.rating
      );
      setData(filteredArr);
    };
    filterSearch();
  }, [filterState, showall, sortByRating]);

  const {
    username,
    address,
    votes,
    reviews,
    image,
    costforone,
    rating,
    min,
  } = formData;

  console.log(filterState, "filterState filterState");

  return (
    <div className="container">
    
    
      <br />
      <div>
        {data.map(
          ({
            username,
            address,
            payment_methods,
            votes,
            reviews,
            image,
            costforone,
            rating,
            min,
          }) => {
            const getPaymentmethod = getCorrectPaymentMethod(payment_methods);

            return (
              <div className="all">
                <div className="flexx">
                  <div className="shadoww">
                    <div className="Rest">
                      <div>
                        {" "}
                        <img src={image} alt=""  width="100%" />
                      </div>
                      <div>
                        <h5 className="name">{username}</h5>
                        <h5 className="add">{address}</h5>
                        <h5 className="add">Cost ₹{costforone} for one</h5>
                        <div className="list">
                          <h5>Min ₹{min} </h5>
                         
                          <li className="upto">Upto 30 min</li>
                        </div>
                       
                      </div>
                      <div>
                      <h5>Accept {getPaymentmethod} payment only</h5>
                        <h6 className="rating">{rating}</h6>
                        <h6 className="add">{votes} votes</h6>
                        <h6 className="add"> {reviews} reviews</h6>
                      </div>
                    </div>
                   
                  </div>
                </div>
              </div>
            );
          }
        )}
      </div>
     
    </div>
  );
};
